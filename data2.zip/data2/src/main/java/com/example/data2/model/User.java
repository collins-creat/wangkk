package com.example.data2.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//User(类)后面处理的数据
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private String username;
    private String password;



}

