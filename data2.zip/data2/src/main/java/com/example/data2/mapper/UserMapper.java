package com.example.data2.mapper;

import com.example.data2.model.User;
import org.apache.ibatis.annotations.*;

//mapper包用于数据处理
//接口，定义全局变量或抽象方法
@Mapper
//处理用户表的映射关系 UserMapper
public interface UserMapper {
    //定义一个方法，将数据放入user表中
    @Insert("insert into user(username,password) values(#{username},#{password})")
    //定义抽象方法，插入user表中的数据,类型是User，通过Insert插入username和password
    void adduser(User user);
    //用注解定义一个抽象方法，查找用户
    @Select("select * from user where username=#{username}")
    //返回User的对象
    User getuser(String  username);//查找库中是否含有此用户名
    //查找库中是否含有与输入匹配的用户名和信息在UserMapper中
    @Select("select * from user where username=#{username} and password=#{password}")
    User login(String username,String password);
    //删除用户方法定义
    @Delete("delete from user where username=#{username}")
    //对于删除，返回的是空用void
    void deleteuser(String username);
    //更新用户的密码
    @Update("update user set password=#{password} where username=#{username}")
    void updateuser(String username,String password);
}

