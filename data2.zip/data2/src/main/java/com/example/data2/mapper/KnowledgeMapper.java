package com.example.data2.mapper;



import com.example.data2.model.Knowledge;
import org.apache.ibatis.annotations.*;

import java.util.List;


@Mapper
public interface KnowledgeMapper {

    //hiController
    @Insert("insert into knowledge(title,content) values(#{title},#{content})")
    void addknowledge(Knowledge knowledge);

    @Delete("delete from knowledge where title=#{title}")
    void deleteknowedge(String title);

    @Select("select * from knowledge where title=#{title}")
    Knowledge getknowledge(String title);

    // @Select("select * from knowledge where title=#{title}")
    // Knowledge checkknowledge(String  title);

    @Update("update knowledge set content=#{content} where title=#{title}")
    void updateknowledge(String title,String content);


    //UserController
    // @Insert("insert into knowledge(title,content) values(#{title},#{content})")
    // void addknowledge(String title, String content);

    //显示知识详情
    @Select("select * from knowledge where title=#{title}")
    List<Knowledge> getallknowledge(String title);
}

