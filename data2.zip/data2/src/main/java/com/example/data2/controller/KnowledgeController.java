package com.example.data2.controller;

import com.example.data2.mapper.KnowledgeMapper;
import com.example.data2.model.Knowledge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;


import java.util.List;
import java.util.Map;


@Controller
public class KnowledgeController {
    @Autowired
    private KnowledgeMapper knowledgeMapper;

    @GetMapping("/addknowledge")
    public String reg(){
        return "index";
    }

    @RequestMapping("/addknowledge")
    public String index(HttpServletRequest request, Map<String,Object> map){
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        Knowledge knowledge=new Knowledge(title,content);
        knowledge.setTitle(title);
        knowledge.setContent(content);

        //添加知识点，先判断库中是否已经含有该知识点,与添加用户同一思路
        Knowledge knowledge1 = knowledgeMapper.getknowledge(title);
        if(knowledge1!=null){
            map.put("msg4","知识点"+title+"已存在！");
            return "index";
        }else {
            knowledgeMapper.addknowledge(knowledge);
            return "detail"; //知识点添加成功后进入detail页面可以查询知识点详情
        }
    }
    //删除知识点，与删除用户同一思路
    @RequestMapping("/deleteknowledge")
    public String deleteknowedge(HttpServletRequest request,Map<String,Object> map){
        String title = request.getParameter("title");
        Knowledge getknowledge = knowledgeMapper.getknowledge(title);
        if(getknowledge!=null){
            knowledgeMapper.deleteknowedge(title);
            map.put("msg5","知识点"+title+"已删除!");
            return "index";
        }else{
            map.put("msg5","知识点"+title+"不存在！");
            return "index";
        }
    }
    //显示查询知识点的内容
    @RequestMapping("/getallknowledge")
    @ResponseBody
    public List<Knowledge> getallknowledge(String title){
        List<Knowledge> getallknowledge = knowledgeMapper.getallknowledge(title);
        return getallknowledge;
    }

    @RequestMapping("/updateknowledge")
    public String update(HttpServletRequest request,Map<String,Object> map){
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        Knowledge getknowledge = knowledgeMapper.getknowledge(title);
        if(getknowledge!=null){
            knowledgeMapper.updateknowledge(title,content);
            map.put("msg6","知识点"+title+"已更新！");
            return "detail";
        }else{
            map.put("msg6","知识点"+title+"不存在！");
            return "detail";
        }
    }
    //返回
    @RequestMapping("/back")
    public String back(){return "index";}
}
