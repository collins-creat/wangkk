package com.example.data2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Data2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
