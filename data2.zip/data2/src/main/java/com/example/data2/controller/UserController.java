package com.example.data2.controller;

import com.example.data2.mapper.UserMapper;
import com.example.data2.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;


@Controller//控制页面,完成注册，登陆，删除，修改（增删改查）
public class UserController {
    @Autowired
    //接口实例化，导入UserMapper数据
    private UserMapper userMapper;
    //定义小的userMapper
    @GetMapping("/register")   //输入路径  register中的action与之相同
    public String reg(){
        return "register";
    }
    @RequestMapping("/register")  //包含requestbody和getmapping
    //执行操作，定义一个方法register
    public String register(HttpServletRequest request,Map<String,Object> map){//页面访问form前端
        String username = request.getParameter("username");
        //getParameter()是string类型，为前端register中定义的的username；alt+enter创建本地的username在等号前
        String password = request.getParameter("password");
        //System.out.println(username);//打印username
        //System.out.println(password);
        //定义User类
        User user=new User(username,password);
        //对user进行初始化
        user.setUsername(username);//合法与adduser冲突
        user.setPassword(password);
        User user1 = userMapper.getuser(username);//把数据写入数据库中
        //判断注册的用户是否已经注册
        if(user1!=null){
            map.put("msg1","用户 "+username+"已注册。请重新注册！");
            return "register";//访问register页面
        }else {
            userMapper.adduser(user);
            return "login"; //访问login页面
        }

    }

    @RequestMapping("/getuser")//调用接口方法，查找用户
    //查询的值返回到前端页面Map
    public String getuser(HttpServletRequest request, Map<String,Object> map){
        String username = request.getParameter("username");
        User user = userMapper.getuser(username);//抽取username
        //判断是否存在
        if(user!=null){
            map.put("msg","用户 "+username+"已被注册!");
            return "register";
        }else{
            map.put("msg","用户"+username+"已被使用");
            return "register";
        }
    }

    @RequestMapping("/login")
    public String login(HttpServletRequest request,Map<String,Object> map){
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        //查找库中是否含有与输入匹配的用户名和信息在UserMapper中
        User loginuser = userMapper.login(username, password);
        System.out.println(loginuser);
        if(loginuser!=null)
        {
            return "index";
        }else
        map.put("msg2","用户"+username+"不存在!");//login.html页面定义msg2
        return "login";
    }

    @RequestMapping("/deleteuser")
    public String deleteuser(HttpServletRequest request,Map<String,Object> map){
        String username = request.getParameter("username");
        User getuser = userMapper.getuser(username);
        if(getuser!=null){
            userMapper.deleteuser(username);
            map.put("msg3","用户"+username+"已删除!");
            return "login";
        }else{
            map.put("msg3","用户"+username+"不存在！");
            return "login";
        }
    }

    @RequestMapping("/updateuser")
    public String update(HttpServletRequest request,Map<String,Object> map){
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        User getuser = userMapper.getuser(username);
        if(getuser!=null){
            userMapper.updateuser(username,password);
            map.put("msg4","用户"+username+"密码已更改！");
            return "login";
        }else{
            map.put("msg4","用户"+username+"不存在！");
            return "login";
        }
    }
}
